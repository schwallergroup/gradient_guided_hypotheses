import setuptools

setuptools.setup(     
     name="sub-module",     
     version="0.7.0",
     python_requires=">=3.8",   
     packages=["GGH"],
)